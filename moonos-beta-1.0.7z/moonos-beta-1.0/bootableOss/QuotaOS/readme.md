Welcome to the QuotaOS Github!

To start the OS:
1. Download the OS
2. Open Bootloader.bat
3. Choose 2 for QuotaOS
4. Have fun with Quota OS! :D